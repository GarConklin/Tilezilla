# Level Catalog

Base tiles: SH, ET, UT, RC, LC, DB, HL, VL, LL, LR
Advanced tiles: SZ, SS, DS, QC, DC

---

## Part 1: BASE-ONLY Levels (ordered lowest to highest)

| # | Level ID | Name | Board | Tiles | Blocker |
|---|----------|------|-------|-------|---------|
| 1 | 2x4-A | Fix 1A | 2x4 | SH, ET, UT, HL | — |
| 2 | 3x3-A | Fix 2A | 3x3 | SH, ET, RC, UT | [0,0] |
| 3 | 3x3-C | Fix 2C | 3x3 | SH, ET, LRx2 | [1,1] |
| 4 | 3x4-A | Fix 3A | 3x4 | SH, ET, UT, RC, LL, LR | — |
| 5 | 3x4-B | Fix 3B | 3x4 | SH, ET, UT, VL, LL, LR | — |
| 6 | 3x4-D | Fix 3D | 3x4 | SH, ET, RC, LR, LL, VL | — |
| 7 | 3x4-E | Fix 3E | 3x4 | SH, ET, UT, RC, LR, VL | — |
| 8 | 3x4-I | Fix 3I | 3x4 | SH, ET, LRx2, LL, VL | — |
| 9 | 3x5-B | Fix 4B | 3x5 | SH, ET, UTx2, LR, HL, LL | [0,0] |
| 10 | 3x6-A | Fix 5A | 3x6 | SH, ET, UTx3, RC, LC, DB, LL | — |
| 11 | 3x6-C | Fix 5C | 3x6 | SH, ET, UTx3, LR, DB, RC, VL | — |
| 12 | 3x6-D | Fix 5D | 3x6 | SH, ET, UTx2, DB, LL, LR, RC, VL | — |
| 13 | 3x6-E | Fix 5E | 3x6 | SH, ET, UT, DB, LL, RCx2, LC, HL | — |
| 14 | 4x4-A | Fix 6A | 4x4 | SH, ET, UT, RC, LL, LR, HL, VL | — |
| 15 | 4x4-C | Fix 6C | 4x4 | SH, ET, UT, RC, LL, LR, VL, DB | — |
| 16 | 4x4-G | Fix 6G | 4x4 | SH, ET, UTx2, DB, HL, LL, LR | — |
| 17 | 4x4-J | Fix 6J | 4x4 | SH, ET, UTx2, HL, LL, RC, VL | — |
| 18 | 4x5-A | Fix 7A | 4x5 | SH, ET, UTx4, RC, LL, LR, HL | — |
| 19 | 4x5-C | Fix 7C | 4x5 | SH, ET, RCx2, UTx2, LL, VL, LR, HL | — |
| 20 | 4x6-C | Fix 8C | 4x6 | SH, ET, UTx3, DB, LLx2, HLx2, RC, LR | — |
| 21 | 6x5-A | Fix AA | 5x6 | SH, ET, UTx6, RCx2, LL, LR, HL, VL, DB | — |
| 22 | 6x6-A | Fix BA | 6x6 | SH, ET, UTx4, RCx4, LLx2, LRx2, HL, VL, DBx2 | — |

**22 base-only levels**

---

## Part 2: ADVANCED Levels (uses at least one of SZ/SS/DS/QC/DC)

| # | Level ID | Name | Board | Advanced tiles used | Blocker |
|---|----------|------|-------|---------------------|---------|
| 1 | 3x3-B | Fix 2B | 3x3 | SZ | [0,0] |
| 2 | 3x4-C | Fix 3C | 3x4 | SZ | — |
| 3 | 3x4-F | Fix 3F | 3x4 | SZ, DC | — |
| 4 | 3x4-G | Fix 3G | 3x4 | DC | — |
| 5 | 3x4-H | Fix 3H | 3x4 | SZ | — |
| 6 | 3x4-J | Fix 3J | 3x4 | SZ | — |
| 7 | 3x4-K | Fix 3K | 3x4 | SZ, SS | — |
| 8 | 3x4-L | Fix 3L | 3x4 | DC | — |
| 9 | 3x4-M | Fix 3M | 3x4 | SZ | — |
| 10 | 3x4-N | Fix 3N | 3x4 | DS | — |
| 11 | 3x5-A | Fix 4A | 3x5 | SZ | [0,0] |
| 12 | 3x5-C | Fix 4C | 3x5 | DC | [0,0] |
| 13 | 3x6-B | Fix 5B | 3x6 | DC | — |
| 14 | 4x4-B | Fix 6B | 4x4 | SZ, SS, DS | — |
| 15 | 4x4-D | Fix 6D | 4x4 | SZ | — |
| 16 | 4x4-E | Fix 6E | 4x4 | DS | — |
| 17 | 4x4-F | Fix 6F | 4x4 | SS, SZ | — |
| 18 | 4x4-H | Fix 6H | 4x4 | SS, SZ | — |
| 19 | 4x4-I | Fix 6I | 4x4 | QC | — |
| 20 | 4x4-K | Fix 6K | 4x4 | DC, DS | — |
| 21 | 4x4-L | Fix 6L | 4x4 | DS, SS | — |
| 22 | 4x4-M | Fix 6M | 4x4 | DS, SZ | — |
| 23 | 4x4-N | Fix 6N | 4x4 | DS | — |
| 24 | 4x4-O | Fix 6O | 4x4 | DS, SZ | — |
| 25 | 4x5-B | Fix 7B | 4x5 | SZ, SS, QC, DS | — |
| 26 | 4x6-A | Fix 8A | 4x6 | DC, QC | — |
| 27 | 4x6-B | Fix 8B | 4x6 | DC, SS, DS | — |
| 28 | 5x5-A | Fix 9A | 5x5 | SZ, SS | [0,0] |
| 29 | 5x5-B | Fix 9B | 5x5 | QC | [0,0] |
| 30 | 5x5-C | Fix 9C | 5x5 | DS | [0,0] |
| 31 | 5x5-D | Fix 9D | 5x5 | SZ | [0,0] |
| 32 | 5x5-E | Fix 9E | 5x5 | SZ | [0,0] |
| 33 | 5x5-F | Fix 9F | 5x5 | SZ | [2,2] |
| 34 | 6x5-B | Fix AB | 5x6 | SZ, SS, DS, QC | — |

**34 advanced levels**

---

**Total: 56 playable levels** (22 base-only + 34 advanced), excluding sandboxes.



Prefix: 1=2x4, 2=3x3, 3=3x4


Content rules
Mode		Show Start	Show End	Inventory includes
EASY		✖			✖			all tiles
HARD start	✖			✖			all tiles
HARD end	✖			✖			all tiles
XTRA HARD	✖			✖			all tiles



Prefix:4=3x5, 5=3x6, 6=4x4, 7=4x5, 8=4x6


Content rules
Mode		Show Start	Show End	Inventory includes
EASY start	✔			✖			everything except start
EASY end	✖			✔			everything except end
HARD start	✖			✖			all tiles
HARD end	✖			✖			all tiles
XTRA HARD	✖			✖			all tiles



Prefix:9=5x5, A=5x6, B=6x6

Content rules
Mode		Show Start	Show End	Inventory includes
EASY		✔			✔			everything except both
HARD start	✔			✖			everything except start
HARD end	✖			✔			everything except end
XTRA HARD	✖			✖			all tiles



